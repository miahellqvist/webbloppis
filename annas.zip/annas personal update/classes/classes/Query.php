<?php
class Query{
	function chooseCategory()
		{
			$query = ("SELECT * FROM category");
			 return $this->query = $query;
		}
		function chooseSubCategory()
		{
			$query = ("SELECT * FROM subcategory");
			 return $this->query = $query;
		}
		//Hämtar användarens user_id
		function getUserid($username)
		{
			$query = ("SELECT user_id FROM user WHERE username = '$username' LIMIT 1");
			 return $this->query = $query;
		}	



		//Hämtar all data i product-tabellen (annonsen)
		function showMinimizedProductAd()
		{
			$query = ("SELECT * FROM product ORDER BY date DESC");
			return $this->query = $query;
		}

		//Hämtar all data i product-tabellen (annonsen) samt deklarerar bildens namn som GET-id
		function showFullProductAd()
		{
			$id=$_GET['id'];
			$query = ("SELECT * FROM product, category, subcategory, state, user
						WHERE product.product_id='$id'
						AND product.category=category.category_id
						AND product.subcategory=subcategory.subcategory_id
						AND user.state=state.state_id
						AND product.user_id=user.user_id");
			return $this->query = $query;
		}
		
		function showProductsByCategory()
		{
			$category_id=$_GET['category'];
			$query = ("SELECT * FROM category, product
						WHERE product.category=category.category_id
						AND category.category_id='$category_id'
						ORDER BY date DESC");
			return $this->query = $query;
		}
		
		function showProductsBySubcategory()
		{
			$subcategory_id=$_GET['subcategory'];
			$query = ("SELECT * FROM subcategory, product
						WHERE product.subcategory=subcategory.subcategory_id
						AND subcategory.subcategory_id='$subcategory_id'
						ORDER BY date DESC");
			return $this->query = $query;
		}
		
		function showProductsByState()
		{
			$state_id=$_GET['state'];
			$query = ("SELECT *
						FROM state, user, product
						WHERE user.state=state.state_id
						AND state.state_id='$state_id'
						AND product.user_id=user.user_id
						ORDER BY product.date DESC");
			return $this->query = $query;
		}
		
		function showProfile()
		{
			$user_id=$_GET['user_id'];
			$query = ("SELECT * FROM user, product
						WHERE user.user_id='$user_id'
						AND product.user_id=user.user_id
						ORDER BY product.date DESC");
			return $this->query = $query;
		}
		//HÃ¤mtar ut sÃ¤ljarens e-post.
		function getUsermail($dbcon)
		{
			$id=$_GET['id'];
			$query =("SELECT user.email FROM user WHERE user.id = '$id'");
			return $this->query = $query;
		}



		function showPersonalProduct($userid)
		{
			$query = ("SELECT * FROM product 
				WHERE user_id=$userid ");
			return $this->query = $query;
		}
		
		function showUsersProducts($user_id)
		{
			$query = ("SELECT * FROM product WHERE user_id=$user_id");
			return $this->query = $query;
		}

		//Hämtar en användares personliga data		
		function personalData($username)
		{
			$query = ("SELECT user_id, name, username,password, email, phone, type_membership_id, adress, zip_code, city FROM user WHERE username ='$username'");
    		return $this->query = $query;
    	}
	

		function dropdownmenu()
		{
			$query=("select subcategory.subcategory_name from subcategory, category, select_category where category.category_id = select_category.category_id and subcategory.subcategory_id = select_category.subcategory_id
			and category.category_name ='Leksaker'");
			return $this->query = $query;

		}

}	