<?php

    class UpdatePersonal{

    	function personalData($dbCon,$query){
    		$html="";
    		$username = $_SESSION['username'];

    		if($result = $dbCon->query($query->personalData($username)))
    		{	
				while($row = $result->fetch_assoc())
				{	
					$user_id= $row['user_id'];
		 			$name = $row['name'];
		 			$username = $row['username'];
		 			$password = $row['password'];
		 			$email = $row['email'];
		 			$phone = $row['phone'];
		 			$membership = $row['type_membership_id'];
		 			$adress = $row['adress'];
		 			$zip_code = $row['zip_code'];
		 			$city = $row['city'];
				}
    		}

    	return "
			<form method=post>
			  <legend>Här kan du uppdatera dina inmatade uppgifter</legend>
			  <input type='hidden' name='id' value='{$user_id}'/>
			  <p><label>Namn:<br/><input type='text' name='name' value='{$name}'/></label></p>
			  <p><label>username:<br/><input type='text' name='username' value='{$username}'/></label></p>
			  <p><label>email:<br/><input type='text' name='email' value='{$email}'/></label></p>
			  <p><label>phone:<br/><input type='text' name='phone' value='{$phone}'/></label></p>
			 
			 <p><select name='membership' required value='{$membership}'>
			 
			 ";
			/* if($membership == 'Brons')
			 {
			 
		/*echo "
			 	<option value='Brons' selected>Brons</option>
		  		<option value='Silver'>Silver</option>
		 		<option value='Guld'>Guld</option>
		 	 ";
		 	 }		
		 	 else if($membership == 'Silver')
		 	{
		echo "	
		 	  	<option value='Brons'>Brons</option>
		  		<option value='Silver' selected>Silver</option>
		 		<option value='Guld'>Guld</option>
		 		";
		 	}
		 	 else
		 	{
		echo " 
		 	 	<option value='Brons'>Brons</option>
		  		<option value='Silver'>Silver</option>
		 		<option value='Guld' selected>Guld</option>
		 		";
		 	 }		*/	
		 	 	
		 	
		/*echo "
				</select> <br></p>
				 <p><label>adress:<br/>
				 <input type='text' name='adress' value='{$adress}'/></label></p>
				 <p><label>zip_code:<br/>
				 <input type='text' name='zip_code' value='{$zip_code}'/></label></p>
				 <p><label>city:<br/>
				 <input type='text' name='city' value='{$city}'/></label></p>
				  <input type='submit' name='saveChanges' value='Spara'>
		*/

		 			
			  
			

			
			return $this->html = $html;
    	}


    	function updatePersonalData($dbCon)
    	{
    		if(isset($_POST['saveChanges']))
    		{
	    		$name = $dbCon->real_escape_string($_POST['name']);
				$username = $dbCon->real_escape_string($_POST['username']);
				$membership = $dbCon->real_escape_string($_POST['membership']);
				$adress = $dbCon->real_escape_string($_POST['adress']);
		 		$zip_code = $dbCon->real_escape_string($_POST['zip_code']);
		 		$city = $dbCon->real_escape_string($_POST['city']);
		 		$email = $dbCon->real_escape_string($_POST['email']);
		 		$phone = $dbCon->real_escape_string($_POST['phone']);
    			//Lägger in i databasen
				$query = ("UPDATE user
						 SET name='$name', username='$username', type_membership_id= '$membership',
							 adress='$adress', zip_code='$zip_code', city='$city', email='$email', phone='$phone'
							WHERE username='$username'");  
							
    			$dbCon->query($query);
    		}

    	}
   }